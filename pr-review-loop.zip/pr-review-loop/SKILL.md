---
name: pr-review-loop
description: Use when a PR needs repeated independent review and repair rounds without copying findings between a coder and reviewer, especially after implementation and PR creation.
---

# PR Review Loop

## Overview

Keep one no-context reviewer alive while the root agent owns triage, fixes, verification, commits, and pushes.

## Rules

- Spawn the reviewer exactly once with `task_name = "pr_reviewer"` and `fork_turns = "none"`.
- Reuse it with `followup_task` for every later round. Do not create a fresh reviewer for independence.
- Keep the reviewer read-only: no edits, commits, pushes, PR comments, labels, or review-thread mutations.
- Make every round inspect the complete current merge diff. Prior findings are a checklist, not the scope.
- Keep the root agent responsible for `$triage` and all writes.

## Start the Loop

1. Read repository instructions and resolve the PR, base branch, merge base, and HEAD.
2. Spawn `pr_reviewer` with `fork_turns = "none"`. Omit model and reasoning overrides unless the user or applicable instructions require them.
3. In the initial message, require the reviewer to:
   - read applicable instructions and use an applicable review skill;
   - review the complete merge diff at the stated HEAD;
   - report every actionable defect with severity and `file:line` evidence;
   - say `No findings.` only after inspecting the whole diff; remain read-only.
4. Wait for the result. A timeout is not completion; check `list_agents` and keep waiting while it runs.

## Triage and Repair

**REQUIRED SUB-SKILL:** Use `triage` for every non-clean review result.

Assess every finding, fix actionable items, verify, and make the proactive checks required by `triage`. Commit and push when repository instructions require it. Record both HEADs, verification, and the complete Triage Update. Never ask the reviewer to repair its findings.

If HEAD changed during review, treat the report as stale. Interrupt the turn when still active, then wake the same reviewer against the new HEAD. Do not triage stale findings first.

## Request the Next Round

Use `followup_task` on `/root/pr_reviewer`. Include:

- the new HEAD;
- the Triage Update, including fixes, false positives, and deferrals;
- relevant verification evidence;
- an explicit request to verify prior findings and perform a fresh full review of the entire current merge diff.

Use `send_message` only for supplementary facts during a running turn. It does not start the next round.

Repeat until a terminal condition is met. Do not stop after one repair round or impose an arbitrary round limit.

## Terminal Conditions

Finish only when the same reviewer reports `No findings.` for the current HEAD and HEAD has not changed since review began.

Stop and ask the user when:

- a finding needs a product, security, architecture, cost, or scope decision;
- the same disputed finding survives one evidence-backed rebuttal without new evidence;
- required verification or push access is unavailable;
- the reviewer thread cannot be restored.

Only for lost-thread recovery, spawn a replacement with `fork_turns = "none"` and disclose lost continuity. Report the PR, clean HEAD, rounds, fixes, verification, and residual risk.
